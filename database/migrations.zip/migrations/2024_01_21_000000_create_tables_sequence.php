<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        // Create Users table first if it doesn't exist
        if (!Schema::hasTable('users')) {
            Schema::create('users', function (Blueprint $table) {
                $table->id();
                $table->string('name');
                $table->string('email')->unique();
                $table->timestamp('email_verified_at')->nullable();
                $table->string('password');
                $table->rememberToken();
                $table->timestamps();
            });
        }

        // Create Properties table first since other tables depend on it
        if (!Schema::hasTable('properties')) {
            Schema::create('properties', function (Blueprint $table) {
                $table->id();
                $table->string('property_name');
                $table->string('compound_name')->nullable();
                $table->string('property_number')->nullable();
                $table->string('unit_no')->nullable();
                $table->enum('unit_for', ['sale', 'rent']);
                $table->enum('type', ['apartment', 'villa', 'duplex', 'penthouse', 'studio', 'office', 'retail', 'land']);
                $table->string('phase')->nullable();
                $table->string('building')->nullable();
                $table->string('floor')->nullable();
                $table->boolean('finished')->default(true);
                $table->decimal('total_area', 10, 2);
                $table->decimal('unit_area', 10, 2)->nullable();
                $table->decimal('land_area', 10, 2)->nullable();
                $table->decimal('garden_area', 10, 2)->nullable();
                $table->decimal('space_earth', 10, 2)->nullable();
                $table->integer('rooms')->nullable();
                $table->integer('bathrooms')->nullable();
                $table->json('amenities')->nullable();
                $table->string('location_type')->nullable();
                $table->string('category')->nullable();
                $table->string('status')->default('available');
                $table->decimal('total_price', 12, 2);
                $table->decimal('price_per_meter', 12, 2)->nullable();
                $table->string('currency')->default('EGP');
                $table->date('rent_from')->nullable();
                $table->date('rent_to')->nullable();
                $table->string('property_offered_by')->nullable();
                $table->string('owner_name')->nullable();
                $table->string('owner_mobile')->nullable();
                $table->string('owner_tel')->nullable();
                $table->string('contact_status')->nullable();
                $table->foreignId('handler_id')->nullable()->constrained('users')->nullOnDelete();
                $table->foreignId('sales_person_id')->nullable()->constrained('users')->nullOnDelete();
                $table->string('sales_category')->nullable();
                $table->text('sales_notes')->nullable();
                $table->foreignId('project_id')->nullable()->constrained()->nullOnDelete();
                $table->text('description')->nullable();
                $table->json('features')->nullable();
                $table->timestamp('last_follow_up')->nullable();
                $table->boolean('is_featured')->default(false);
                $table->timestamps();
                $table->softDeletes();
            });
        }

        // Create Projects table
        if (!Schema::hasTable('projects')) {
            Schema::create('projects', function (Blueprint $table) {
                $table->id();
                $table->string('name');
                $table->text('description')->nullable();
                $table->string('location')->nullable();
                $table->string('developer')->nullable();
                $table->string('status')->nullable();
                $table->date('launch_date')->nullable();
                $table->date('completion_date')->nullable();
                $table->string('featured_image')->nullable();
                $table->timestamps();
                $table->softDeletes();
            });
        }

        // Skip creating properties table as it's handled in a separate migration

        // Create Property Media table after properties table exists
        if (!Schema::hasTable('property_media')) {
            Schema::create('property_media', function (Blueprint $table) {
                $table->id();
                $table->foreignId('property_id')->constrained()->cascadeOnDelete();
                $table->string('file_path');
                $table->boolean('is_featured')->default(false);
                $table->integer('sort_order')->default(0);
                $table->timestamps();
            });
        }

        // Create Leads table after properties table exists
        if (!Schema::hasTable('leads')) {
            Schema::create('leads', function (Blueprint $table) {
                $table->id();
                $table->string('first_name');
                $table->string('last_name');
                $table->string('email')->nullable();
                $table->string('phone')->nullable();
                $table->string('mobile')->nullable();
                $table->string('status')->default('new');
                $table->string('source')->nullable();
                $table->decimal('budget', 15, 2)->nullable();
                $table->foreignId('property_interest')->nullable()->constrained('properties')->nullOnDelete();
                $table->foreignId('assigned_to')->nullable()->constrained('users')->nullOnDelete();
                $table->foreignId('last_modified_by')->nullable()->constrained('users')->nullOnDelete();
                $table->text('notes')->nullable();
                $table->string('lead_class')->nullable();
                $table->timestamp('last_follow_up')->nullable();
                $table->timestamps();
                $table->softDeletes();
            });
        }

        // Create Opportunities table last
        if (!Schema::hasTable('opportunities')) {
            Schema::create('opportunities', function (Blueprint $table) {
                $table->id();
                $table->string('title');
                $table->foreignId('lead_id')->nullable()->constrained()->nullOnDelete();
                $table->foreignId('property_id')->nullable()->constrained()->nullOnDelete();
                $table->foreignId('assigned_to')->nullable()->constrained('users')->nullOnDelete();
                $table->string('status')->default('new');
                $table->decimal('value', 12, 2)->nullable();
                $table->decimal('probability', 5, 2)->nullable();
                $table->date('expected_close_date')->nullable();
                $table->text('description')->nullable();
                $table->text('notes')->nullable();
                $table->string('source')->nullable();
                $table->string('stage')->nullable();
                $table->string('type')->nullable();
                $table->string('priority')->nullable();
                $table->timestamp('last_activity_at')->nullable();
                $table->foreignId('last_modified_by')->nullable()->constrained('users')->nullOnDelete();
                $table->timestamps();
                $table->softDeletes();
            });
        }
    }

    public function down()
    {
        // Drop tables in reverse order of dependencies
        Schema::dropIfExists('opportunities');
        Schema::dropIfExists('leads');
        Schema::dropIfExists('property_media');
        Schema::dropIfExists('properties');
        Schema::dropIfExists('projects');
        Schema::dropIfExists('users');
    }
};
